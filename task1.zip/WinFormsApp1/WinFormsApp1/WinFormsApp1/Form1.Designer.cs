﻿namespace WinFormsApp1
{
    partial class Task1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Enter = new Button();
            Saveas = new Button();
            AddUppercase = new CheckBox();
            AddDigits = new CheckBox();
            AddSpecials = new CheckBox();
            PasswordLength = new NumericUpDown();
            lepassword = new TextBox();
            ((System.ComponentModel.ISupportInitialize)PasswordLength).BeginInit();
            SuspendLayout();
            // 
            // Enter
            // 
            Enter.Location = new Point(55, 194);
            Enter.Margin = new Padding(4, 5, 4, 5);
            Enter.Name = "Enter";
            Enter.Size = new Size(401, 100);
            Enter.TabIndex = 0;
            Enter.Text = "Показати мій результат!";
            Enter.UseVisualStyleBackColor = true;
            Enter.Click += Hope_Click;
            // 
            // Saveas
            // 
            Saveas.Location = new Point(464, 194);
            Saveas.Margin = new Padding(4, 5, 4, 5);
            Saveas.Name = "Saveas";
            Saveas.Size = new Size(356, 100);
            Saveas.TabIndex = 1;
            Saveas.Text = "Зберегти пароль як...";
            Saveas.UseVisualStyleBackColor = true;
            Saveas.Click += Hope2_Click;
            // 
            // AddUppercase
            // 
            AddUppercase.AutoSize = true;
            AddUppercase.Location = new Point(55, 40);
            AddUppercase.Margin = new Padding(4, 5, 4, 5);
            AddUppercase.Name = "AddUppercase";
            AddUppercase.Size = new Size(152, 29);
            AddUppercase.TabIndex = 2;
            AddUppercase.Text = "Великі літери?";
            AddUppercase.UseVisualStyleBackColor = true;
            // 
            // AddDigits
            // 
            AddDigits.AutoSize = true;
            AddDigits.Location = new Point(215, 40);
            AddDigits.Margin = new Padding(4, 5, 4, 5);
            AddDigits.Name = "AddDigits";
            AddDigits.Size = new Size(94, 29);
            AddDigits.TabIndex = 3;
            AddDigits.Text = "Числа?";
            AddDigits.UseVisualStyleBackColor = true;
            // 
            // AddSpecials
            // 
            AddSpecials.AutoSize = true;
            AddSpecials.Location = new Point(317, 40);
            AddSpecials.Margin = new Padding(4, 5, 4, 5);
            AddSpecials.Name = "AddSpecials";
            AddSpecials.Size = new Size(198, 29);
            AddSpecials.TabIndex = 4;
            AddSpecials.Text = "Особливі символи?";
            AddSpecials.UseVisualStyleBackColor = true;
            // 
            // PasswordLength
            // 
            PasswordLength.Location = new Point(55, 98);
            PasswordLength.Margin = new Padding(4, 5, 4, 5);
            PasswordLength.Name = "PasswordLength";
            PasswordLength.Size = new Size(460, 31);
            PasswordLength.TabIndex = 5;
            // 
            // lepassword
            // 
            lepassword.Location = new Point(556, 64);
            lepassword.Margin = new Padding(4, 5, 4, 5);
            lepassword.Name = "lepassword";
            lepassword.Size = new Size(264, 31);
            lepassword.TabIndex = 6;
            // 
            // Task1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(lepassword);
            Controls.Add(PasswordLength);
            Controls.Add(AddSpecials);
            Controls.Add(AddDigits);
            Controls.Add(AddUppercase);
            Controls.Add(Saveas);
            Controls.Add(Enter);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Task1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)PasswordLength).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Enter;
        private Button Saveas;
        private CheckBox AddUppercase;
        private CheckBox AddDigits;
        private CheckBox AddSpecials;
        private NumericUpDown PasswordLength;
        private TextBox lepassword;
    }
}