using System;
using System.Linq;
using System.Windows.Forms;
using System.IO;


namespace WinFormsApp1
{
    public partial class Task1 : Form
    {

        private const string LowercaseLetters = "abcdefghijklmnopqrstuvwxyz";
        private const string UppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private const string Digits = "0123456789";
        private const string SpecialCharacters = "!@#$%^&*()_+-=[]{};:,.<>?";

        private readonly Random random = new Random();

        public Task1()
        {
            InitializeComponent();
        }

        private void Hope_Click(object sender, EventArgs e)
        {
            int length = (int)PasswordLength.Value;
            bool useUppercase = AddUppercase.Checked;
            bool useDigits = AddDigits.Checked;
            bool useSpecialCharacters = AddSpecials.Checked;

            string password = GeneratePassword(length, useUppercase, useDigits, useSpecialCharacters);
            lepassword.Text = password;
        }

        private string GeneratePassword(int length, bool useUppercase, bool useDigits, bool useSpecialCharacters)
        {
            string characters = LowercaseLetters;
            if (useUppercase)
                characters += UppercaseLetters;
            if (useDigits)
                characters += Digits;
            if (useSpecialCharacters)
                characters += SpecialCharacters;

            char[] password = new char[length];
            for (int i = 0; i < length; i++)
            {
                password[i] = characters[random.Next(characters.Length)];
            }

            password = password.OrderBy(c => random.Next()).ToArray();

            return new string(password);
        }

        private void Hope2_Click(object sender, EventArgs e)
        {
            string password = lepassword.Text;
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("No password generated.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 1;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog.FileName, password);
                MessageBox.Show("Password saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        
    }
}